import { EditDelivery } from "./Delivery.js";

const deliveryArr = [
  new EditDelivery("Ольга", "ул. Вымыслов, д. 12", 8, "delivery"),
  new EditDelivery("Дмитрий", "ул. Задачная, д. 7", 3, "delivered"),
  new EditDelivery("Оля", "ул. Ткачей, д. 43", 11, "canceled")
];

const container = document.getElementById("delivery-container");
const resultBlock = document.getElementById("total-result");
const button = document.getElementById("calc-distance");

deliveryArr.forEach(delivery => {
  const card = delivery.createCardElement();
  container.appendChild(card);
});

button.addEventListener("click", () => {
  const total = EditDelivery.getTotalDistance(deliveryArr);
  resultBlock.textContent = `Общее расстояние: ${total} км`;
});
